#ifndef NOTEPAD_H
#define NOTEPAD_H
#include "ui_notepad.h"
#include "pagemanager.h"
#include "joueur.h"
#include <QMainWindow>
#include <QProgressBar>
QT_BEGIN_NAMESPACE
namespace Ui { class Notepad; }
QT_END_NAMESPACE

class Notepad : public QMainWindow
{
    Q_OBJECT

public:
    Notepad(QWidget *parent = nullptr);
    ~Notepad();

private:
    Ui::Notepad *ui;
    QString currentFile;
    PageManager management;
    QList<QPushButton*> m_buttons;
    int nb =0;
    Joueur maqu;
    bool img,lien,erase;
    QString currentIMG,fileName,linkFile,classic;
    QProgressBar* progressBar;
    QProgressBar* progresseBarXP;

private slots:
void on_actionNew_triggered();
void on_actionOpen_triggered();
void on_actionSave_triggered();
void on_actionSave_as_triggered();
void on_actionExit_triggered();
void selectFont();
void setItalic(bool italic);
void setUnderline(bool underline);
void setFontWeight(bool font);
void PopupMenu();
//void on_pushButton_pressed();
void on_actionShow_triggered();
//QString on_pushButton_2_pressed();
void on_pushButton_3_clicked();
void on_pushButton_clicked();
void on_pushButton_2_clicked();
void on_pushButton_pressed();
void selectColor();
void selectFontColor();
void undo();
void redo();
void on_actionCopy_triggered();
void on_actionPaste_triggered();
void on_actionCut_triggered();
void openImage();
void createHtmlFile(const QString& filePath, const QString& htmlContent);
void on_pushButton_4_clicked();
void on_pushButton_5_clicked();
void on_pushButton_6_clicked();
};
#endif // NOTEPAD_H
