#include "notepad.h"
#include "ui_notepad.h"
#include <QFileDialog>
#include <QFile>
#include <QMessageBox>
#include <QApplication>
#include <QFontDialog>
#include "page.h"
#include "pagemanager.h"
#include <iostream>
#include <string>
#include <QFrame>
#include <QLabel>
#include <QtWidgets/QColorDialog>
#include <QMessageBox>
#include <QImage>
#include <QTextEdit>
#include <QGraphicsPixmapItem>
#include <QGraphicsScene>
#include <QMimeData>
#include <QDragEnterEvent>
#include <QDragMoveEvent>
#include <QDropEvent>
using namespace std;

Notepad::Notepad(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Notepad)
{
    ui->setupUi(this);

    connect(ui->actionFont, &QAction::triggered, this, &Notepad::selectFont);
    connect(ui->actionItalic, &QAction::triggered, this, &Notepad::setItalic);
    connect(ui->actionUnderline, &QAction::triggered, this, &Notepad::setUnderline);
    connect(ui->actionFontWeight, &QAction::triggered, this, &Notepad::setFontWeight);
    connect(ui->actionabout, &QAction::triggered, this, &Notepad::PopupMenu);
    connect(ui->actionColor, &QAction::triggered, this, &Notepad::selectColor);
    connect(ui->actionFontColor, &QAction::triggered, this, &Notepad::selectFontColor);
    connect(ui->actionUndo, &QAction::triggered, this, &Notepad::undo);
    connect(ui->actionRedo, &QAction::triggered, this, &Notepad::redo);
    connect(ui->actionopenImage, &QAction::triggered, this, &Notepad::openImage);

    progressBar = ui->progressBar;
    progressBar->setMinimum(0);
    progressBar->setMaximum(100);
    progressBar->setValue(maqu.getPV());
    progresseBarXP = ui->progressBar_XP;
    progresseBarXP->setMinimum(0);
    progresseBarXP->setMaximum(100);
    progresseBarXP->setValue(maqu.getXP());
    progresseBarXP->setStyleSheet("QProgressBar::chunk { background-color: rgb(0, 120, 215); }");


}

void Notepad::PopupMenu(){

}

void Notepad::setItalic(bool italic)
{
ui->textEdit->setFontItalic(!ui->textEdit->fontItalic());
}

void Notepad::on_pushButton_pressed()
{
    QString b = ui->textEdit->toPlainText();
    Page a(b,nb);
    nb++;
    a.setText(b);
    management.addPage(a);
}



void Notepad::on_actionCopy_triggered()
{
    ui->textEdit->copy();
}


void Notepad::on_actionPaste_triggered()
{
    ui->textEdit->paste();
}


void Notepad::on_actionCut_triggered()
{
    ui->textEdit->cut();
}

void Notepad::setUnderline(bool underline) {
ui->textEdit->setFontUnderline(!ui->textEdit->fontUnderline());
}


void Notepad::undo()
{
    ui->textEdit->undo();
}

void Notepad::redo()
{
    ui->textEdit->redo();
}

void Notepad::setFontWeight(bool arg1) {
    if (ui->textEdit->fontWeight()== QFont::Bold)


            ui->textEdit->setFontWeight(QFont::Normal);


        else


            ui->textEdit->setFontWeight(QFont::Bold);

}

void Notepad::selectFontColor()
{
    QColor color = QColorDialog::getColor(Qt::white, this);
    if (color.isValid()) {
        QPalette palette = ui->textEdit->palette();
        palette.setColor(QPalette::Base, color);
        ui->textEdit->setPalette(palette);
    }
}

void Notepad::selectColor()
{
    QColor color = QColorDialog::getColor(Qt::white, this);
    if (color.isValid()) {
        QTextCharFormat textCharFormat;
        textCharFormat.setForeground(color);
        ui->textEdit->setTextColor(color);
        ui->textEdit->mergeCurrentCharFormat(textCharFormat);
    }
}
void Notepad::selectFont() {
    bool fontSelected;
    QFont font = QFontDialog::getFont(&fontSelected, this);
    if (fontSelected)
    ui->textEdit->setCurrentFont(font);
}

Notepad::~Notepad()
{
    delete ui;
}



void Notepad::on_actionNew_triggered()
{
currentFile.clear();
ui->textEdit->setText(QString());
maqu.setPV(50);
maqu.setXP(0);
maqu.setLVL(0);
ui->textEdit_3->setText(QString::number(maqu.getPV()));
ui->textEdit_4->setText(QString::number(maqu.getXP()));
progressBar->setValue(maqu.getPV());
progresseBarXP->setValue(maqu.getXP());



}

void Notepad::on_actionOpen_triggered()
{
QString fileName = QFileDialog::getOpenFileName(this, "Open the file");
if (fileName.isEmpty())
return;
QFile file(fileName);
currentFile = fileName;
if (!file.open(QIODevice::ReadOnly | QFile::Text)) {
QMessageBox::warning(this, "Warning", "Cannot open file: " +
file.errorString());
return;
}


setWindowTitle(fileName);
QTextStream in(&file);
QString text = in.readAll();
ui->textEdit->setText(text);

QString b = ui->textEdit->toPlainText();
Page a(b,nb);
nb++;
a.setText(b);
management.addPage(a);



file.close();
}

void Notepad::createHtmlFile(const QString& filePath, const QString& htmlContent)

{

    QFile file(filePath);

    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))

    {

        QMessageBox::critical(this, "Erreur d'exportation", "Impossible de créer le fichier HTML : " + file.errorString());

            return;

    }


    QTextStream out(&file);

    out << htmlContent;


    file.close();

}

void Notepad::on_actionSave_triggered() {
    if(!currentFile.isEmpty()){

        QFile file(currentFile);

        if(!file.open(QIODevice::WriteOnly | QFile::Text)){

            QMessageBox::warning(this, "Warning", "Cannot save file:" + file.errorString());

            return;

        }

        QString addimgv2;
        if (img == true) {
            QString addimg = ui->textEdit->toPlainText();
            addimgv2 = addimg+" <img src='file:///"+currentIMG+"' alt='Image présente sur l'application'>";
            ui->textEdit->setText(addimgv2);
        }
        if (lien == true){
            QString addlink =addimgv2+" <a href='file:///"+linkFile+"'> Lien vers autre page </a>";
            ui->textEdit->setText(addlink);
        }

        QString b = ui->textEdit->toPlainText();
        Page a(b,nb);
        nb++;
        a.setText(b);
        management.addPage(a);

        QString htmlContent = ui->textEdit->toHtml();


        createHtmlFile(currentFile, htmlContent);


        QMessageBox::information(this, "Exportation réussie", "Le fichier a été exporté avec succès.");

        setWindowTitle(currentFile);

        QTextStream out(&file);

        out << ui->textEdit->toPlainText();

        file.close();

    } else {

        on_actionSave_as_triggered();

    }
}


void Notepad::on_actionSave_as_triggered() {
     fileName = QFileDialog::getSaveFileName(this,tr( "Save the file"),R"(Z:\QMAKE\Notepad)",tr("Text files (*.txt)::HTML files (*.html)"));

    if (fileName.isEmpty())

        return;

    QFile file(fileName);

    currentFile = fileName;

    if (!file.open(QIODevice::WriteOnly | QFile::Text)) {

        QMessageBox::warning(this, "Warning", "Cannot save file:" + file.errorString());

        return;


    }
    QString addimgv2;
    if (img == true) {
        QString addimg = ui->textEdit->toPlainText();
        addimgv2 = addimg+" <img src='file:///"+currentIMG+"' alt='Image présente sur l'application'>";
        ui->textEdit->setText(addimgv2);
    }
    if (lien == true){
        QString addlink =addimgv2+" <a href='file:///"+linkFile+"'> Lien vers autre page </a>";
        ui->textEdit->setText(addlink);
    }

    QString b = ui->textEdit->toPlainText();
    Page a(b,nb);
    nb++;
    a.setText(b);
    management.addPage(a);

    QString htmlContent = ui->textEdit->toHtml();


    createHtmlFile(fileName, htmlContent);


    QMessageBox::information(this, "Exportation réussie", "Le fichier a été exporté avec succès.");

    setWindowTitle(fileName);

    QTextStream out(&file);

    out << ui->textEdit->toPlainText();

    file.close();
}

void Notepad::on_actionExit_triggered() {
    close();

}


void Notepad::on_actionShow_triggered() {
   cout << management.getPageCount() << endl;
}


void Notepad::on_pushButton_3_clicked()
{
    bool ok;
    if (management.getPageCount() >= management.getPageInt(ui->textEdit_2->toPlainText().toInt(&ok))) {
     ui->textEdit->setText(management.getPage(ui->textEdit_2->toPlainText().toInt(&ok)).getText());
    }
    else {
        QString error = "Il n'existe aucune page a cet index";
        ui->textEdit->setText(error);
    }
}


void Notepad::on_pushButton_clicked()
{
    bool ok;

    maqu.addPV(ui->textEdit_3->toPlainText().toInt(&ok));
    QString b = ui->textEdit->toPlainText();
    if (maqu.getPV() > 0) {
        ui->textEdit->setText(b+" PV ACTUELS : "+ QString::number(maqu.getPV()));
        progressBar->setValue(maqu.getPV()); // Mettez à jour la valeur de la barre de progression
    }
    else {
        ui->textEdit->setText(b+" PERSONNAGE MORT");
        progressBar->setValue(0); // Le personnage est mort, définissez la valeur de la barre de progression à 0
    }
}


void Notepad::on_pushButton_2_clicked()
{
    bool ok;

    maqu.addXP(ui->textEdit_4->toPlainText().toInt(&ok));
    QString b = ui->textEdit->toPlainText();
    ui->textEdit->setText(b + "<h1> XP ACTUEL : "+ QString::number(maqu.getXP())+"</h1>");
    QString level =  " Niveau : "+QString::number(maqu.getLVL());
    ui->textEdit_5->setText(level);
    QString setlevel = ui->textEdit->toPlainText();
    ui->textEdit->setText(setlevel+"<h1>NIVEAU :" +QString::number(maqu.getLVL()) +"</h1>");
    progresseBarXP->setValue(maqu.getXP());

}

void Notepad::openImage()
{
    QString imagePath = QFileDialog::getOpenFileName(this, "Open Image", "", "Image Files (*.png *.jpg *.bmp)");
    if (!imagePath.isEmpty())
    {
        QImage image(imagePath);
        if (!image.isNull())
        {
            ui->imageLabel->setPixmap(QPixmap::fromImage(image));
            ui->imageLabel->setScaledContents(true);
            img = true;
            currentIMG = imagePath;
        }
        else
        {
            QMessageBox::warning(this, "Error", "Failed to open the image file!");
        }
    }
}


void Notepad::on_pushButton_4_clicked()
{
    linkFile = QFileDialog::getOpenFileName(this, "Open the file");
    if (linkFile.isEmpty())
    return;
    QFile file(linkFile);
    file.close();
    lien = true;
}


void Notepad::on_pushButton_5_clicked()
{
    classic = ui->textEdit->toPlainText();
    QString htmlContent = ui->textEdit->toHtml();
    ui->textEdit->setPlainText(htmlContent);
    erase = true;

}


void Notepad::on_pushButton_6_clicked()
{
    if (erase == true) {
    ui->textEdit->setText(classic);
    }
}

