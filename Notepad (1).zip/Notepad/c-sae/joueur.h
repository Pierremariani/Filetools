#ifndef JOUEUR_H
#define JOUEUR_H


class Joueur
{
    int PV;
    int XP;
    int LVL;
public:
    Joueur();
    Joueur(int PV, int XP);
    int getPV();
    int getXP();
    void setPV(int newPV);
    void setXP(int newXP);
    void addPV(int amount);
    void addXP(int amount);
    int veriflvl();
    int getLVL();
    void setLVL(int lvl);
};

#endif // JOUEUR_H
