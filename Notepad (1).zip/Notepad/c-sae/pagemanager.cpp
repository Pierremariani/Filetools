#include "pagemanager.h"
#include "page.h"
#include <QString>
#include <QList>
#include <string>
#include <iostream>
using namespace std;

PageManager::PageManager()
{

}

void PageManager::addPage(const Page &page) {

        m_pages.append(page);

}

void PageManager::removePage(int pageIndex){
    if (pageIndex >= 0 && pageIndex < m_pages.size()) {
            m_pages.removeAt(pageIndex);
        }
}

Page PageManager::getPage(int pageIndex) const {
    return m_pages.at(pageIndex);
}

int PageManager::getPageCount() const {
    return m_pages.size();
}

int PageManager::getPageInt(int pageIndex) const {
    return pageIndex;
}

QList<int> PageManager::getLinkedPages(int pageIndex) const {
    if (pageIndex >= 0 && pageIndex < m_pages.size()) {
           return m_pages.at(pageIndex).getLinkedPages();
       }
       return QList<int>();
}

bool operator == (Page &a,Page &e) {
    if (a.getText() == e.getText() | a.m_pageIndex == e.m_pageIndex) {
        return false;
    }
    else {
        return true;
    }
}
