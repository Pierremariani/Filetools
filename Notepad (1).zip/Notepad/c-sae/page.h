#ifndef PAGE_H
#define PAGE_H
#include <QString>
#include <QList>
#include <string>
#include <iostream>
using namespace std;



class Page
{
public:
    int m_pageIndex;
    Page(QString text, int indexPage);
    QString getText() const;
    void setText(const QString text);
    QList<int> getLinkedPages() const;
    void addLinkedPage(int pageIndex);
    bool hasLinkedPage(int pageIndex) const;
    string toString();
    int getInt() const;


    private:
        QString m_text;
        QList<int> m_linkedPages;
};

#endif // PAGE_H
