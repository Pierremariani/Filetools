#ifndef PAGEMANAGER_H
#define PAGEMANAGER_H
#include "page.h"
#include <QString>
#include <QList>
#include <string>
#include <iostream>
using namespace std;


class PageManager
{
public:
    PageManager();
    void addPage(const Page& page);
    void removePage(int pageIndex);
    Page getPage(int pageIndex) const;
    int getPageInt(int pageIndex) const;
    int getPageCount() const;
    QList<int> getLinkedPages(int pageIndex) const;
    friend bool operator == (Page &a,Page &e);
private :
    QList<Page> m_pages;

};
bool operator == (Page &a,Page &e);

#endif // PAGEMANAGER_H
