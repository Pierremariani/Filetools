#include "notepad.h"
#include "page.h"
#include <QApplication>
#include <string>
#include <iostream>
using namespace std;


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Notepad w;
    w.show();
    return a.exec();

    Page p("test",0);
    Page e("oui",1);
    Page i("stiti",2);

    p.addLinkedPage(2);
    p.getLinkedPages();

}
