#include "joueur.h"
#include <iostream>
using namespace std;

Joueur::Joueur() {

}
Joueur::Joueur(int PV , int XP)
{
    if (this->PV < 0 || this->XP < 0) {
        this->PV = 100;
        this->XP = 0;
    }
    this->PV = PV;
    this->XP = XP;
    this->LVL = 0;
}

int Joueur::getPV() {
    return PV;
}

int Joueur::getXP() {
    return XP;
}

void Joueur::setPV(int newPV) {
    PV = newPV;
}

void Joueur::setXP(int newXP) {
    XP = newXP;
}

void Joueur::addPV(int amount) {
    PV += amount;
}

void Joueur::addXP(int amount) {
    XP += amount;
    veriflvl();
}

int Joueur::veriflvl() {
    while (XP >= 100) {
        int XP2 = XP;
        XP = XP2-100;
        LVL++;
    }
    cout << LVL << endl;
    return LVL;
}

int Joueur::getLVL() {
    return LVL;
}

void Joueur::setLVL(int lvl){
    this->LVL = lvl;
}
