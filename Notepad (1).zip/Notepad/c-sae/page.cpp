#include "page.h"
#include <QString>
#include <QList>
#include <string>
#include <iostream>
using namespace std;



Page::Page(QString text, int pageIndex)
    : m_text(text), m_pageIndex(pageIndex)
{

}

QString Page::getText() const{
    return m_text;
}

int Page::getInt() const {
    bool ok;
    return m_text.toInt(&ok);
}

void Page::setText(const QString text) {
    m_text = text;
}

void Page::addLinkedPage(int pageIndex) {
    if (!m_linkedPages.contains(pageIndex)) {
        m_linkedPages.append(pageIndex);
        cout << "Page numéro " << pageIndex << " ajoutée "<< endl;
    }
}

QList<int> Page::getLinkedPages() const {
    return m_linkedPages;
}

bool Page::hasLinkedPage(int pageIndex) const{
    if (m_linkedPages.contains(pageIndex)) {
        return true;
    }
    else {
        return false;
    }
}


